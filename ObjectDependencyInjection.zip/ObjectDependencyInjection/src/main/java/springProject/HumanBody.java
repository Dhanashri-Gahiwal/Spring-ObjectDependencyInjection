package springProject;

public class HumanBody {
	private HumanHeart humanHeart;

	public HumanBody(HumanHeart humanHeart) {
		super();
		this.humanHeart = humanHeart;
	}
	
	public void bodyMethod() {
		if(humanHeart!=null) {
			System.out.println("Human is alive");
		}
		else {
			System.out.println("Human is not alive");
		}
	}
}
