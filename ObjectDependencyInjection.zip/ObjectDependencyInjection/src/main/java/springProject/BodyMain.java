package springProject;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BodyMain {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		HumanBody hb = (HumanBody) ctx.getBean("humanBody");
		hb.bodyMethod();

	}

}
