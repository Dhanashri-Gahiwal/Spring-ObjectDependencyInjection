package springProject;

public class HumanHeart {
	public void heart() {
		System.out.println("Heart is beating");
	}
}
