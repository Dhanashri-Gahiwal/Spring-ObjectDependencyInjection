package springProject;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainTextEditor {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		TextEditor te = (TextEditor) ctx.getBean("textEditor");
		te.checkSpelling();

	}

}
