package springProject;

public class TextEditor {
	private SpellCheck spellCheck;

	public TextEditor(SpellCheck spellCheck) {
		super();
		this.spellCheck = spellCheck;
	}
	
	public void checkSpelling() {
		if(spellCheck!=null) {
			System.out.println("Spell is correct");
		}
		else {
			System.out.println("Spell is not correct");
		}
	}
}
